Extract pre-trained models to this folder.

You should expect these files in this folder:

``` bash
experiments
├─lafan1_context_model_release
│      checkpoint_lafan1_context_model_release.pth
│      train_stats_context.pkl
│
└─lafan1_detail_model_release
        checkpoint_lafan1_detail_model_release.pth
        train_stats_context.pkl
        train_stats_detail.pkl
```
